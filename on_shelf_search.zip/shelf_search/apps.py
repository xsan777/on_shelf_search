from django.apps import AppConfig


class ShelfSearchConfig(AppConfig):
    name = 'shelf_search'
